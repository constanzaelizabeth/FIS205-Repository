Organización del desarrollo de la Tarea 3 de FIS205:

Problem 1:
	1.1- Tarea_3_Nahuelhual_Constanza_FIS205.pdf
	1.2- Tarea_3_Nahuelhual_Constanza_FIS205.pdf
	1.3- Hanoi.cc
	1.4- Function.py

Problem 2:
	SquareRoot.cc

Problem 3:
	Palindrome.cc
	Palindrome¿.dat

Problem 4:
	4.1- Tarea_3_Nahuelhual_Constanza_FIS205.pdf
	4.2- Tarea_3_Nahuelhual_Constanza_FIS205.pdf
	4.3- Tarea_3_Nahuelhual_Constanza_FIS205.pdf

Ejecutar códigos .cc:
	g++ Código.cc
	./a.out
