#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

class Polynomial {
private:
    //define la variable que guarda el grado del polinomio
    int grade;
    //vector que almacena los coeficientes del polinomio
    vector<double> coef;

public:
    //constructor que redimensiona el vector de coeficientes para que coincida con el máx valor del grado, establece los coef en 0.0
    Polynomial(int gr) : grade(gr) {
        coef.resize(grade + 1, 0.0);}
    //asigna los coeficientes a los términos del polinomio
    void CreateCoef(int exp, double num) {
        if (exp >= 0 && exp <= grade){coef[exp] = num;}
        else {cout << "Error en el exponente" << endl;}}
    //obtiene el coeficiente de un término del polinomio dado el exponente
    double CCoef(int exp) const {
        if (exp >= 0 && exp <= grade){return coef[exp];}
        else {return 0.0;}}
    //imprime el polinomio
    void Print() const {
        for (int i = grade; i >= 0; --i) {
            if (coef[i] != 0.0) {
                cout << coef[i] << "x^" << i;
                if (i > 0) {cout << " + ";}}}
        cout << endl;}
    //calcula la suma de dos polinomios y devuelve el resultado
    Polynomial Sum(const Polynomial& other) const {
        int MaxGr = max(grade, other.grade);
        Polynomial result(MaxGr);
        for (int i = 0; i <= MaxGr; ++i) {
            //calcula la suma
            double sum = CCoef(i) + other.CCoef(i);
            //guarda el resultado
            result.CreateCoef(i, sum);}
        //retorna el resultado
        return result;}
    //calcula la multiplicación de dos polinomios
    Polynomial Mult(const Polynomial& other) const {
        int MaxGr = max(grade, other.grade);
        Polynomial result(MaxGr);
        for (int i = 0; i <= MaxGr; ++i) {
            //calcula la multiplicación
            double mult = CCoef(i) * other.CCoef(i);
            //guarda el resultado
            result.CreateCoef(i, mult);}
        //retorna el resultado
        return result;}
    //función que calcula la multiplicación de dos polinomios
    void Sum(const Polynomial& other, Polynomial& result) const {
    int MaxGr = max(grade, other.grade);
    result = Polynomial(MaxGr); // Reinicializar el polinomio resultante
    for (int i = 0; i <= MaxGr; ++i) {
        double sum = CCoef(i) + other.CCoef(i);
        result.CreateCoef(i, sum);}};
    //función que calcula la multiplicación de dos polinomios
    void Mult(const Polynomial& other, Polynomial& result) const {
    int MaxGr = max(grade, other.grade);
    result = Polynomial(MaxGr); // Reinicializar el polinomio resultante
    for (int i = 0; i <= MaxGr; ++i) {
        double mult = CCoef(i) * other.CCoef(i);
        result.CreateCoef(i, mult);}};


};

int main() {
    //abre un archivo para guardar los polinomio (no funcionó)
    ofstream archive("Polynomial.txt", ios::out | ios::binary);
    if (!archive) {
        cout << "Error al abrir el archivo" << endl;
        return 1;}
    //define la variable que denomina el número de polinomios
    int NumPol;
    cout << "Escribe 0 si deseas terminar." << endl;
    cout << "Escribe el número de polinomios que deseas crear: ";
    cin >> NumPol;
    //vector que guarda los polinomios
    std::vector<Polynomial> poly;
    if (NumPol == 0){return 0;}
    //ciclo for que pide los valores en pantalla
    for (int j = 0; j < NumPol; ++j) {
        int grade;
        double num;
        cout << "Escribe el grado del polinomio: ";
        cin >> grade;
        //crea un objeto "P" de la clase Polynomial
        Polynomial P(grade);
        for (int i = grade; i >= 0; --i) {
            cout << "Escribe el coeficiente que acompaña a: x^" << i << ": ";
            cin >> num;
            P.CreateCoef(i, num);
        }
        //agrega los polinomios al vector
        poly.push_back(P);
        cout << "El polinomio es: ";
        P.Print();
    }

    int k;
    cout << "Escribe 0 si deseas sumarlos o bien, 1 si deseas multiplicarlos: ";
    cin >> k;
    if (k == 0) {
        cout << "La suma de los polinomios es: ";
        //inicializa el objeto sumResult
        Polynomial sumResult = poly[0];
        for (int i = 1; i < NumPol; ++i) {
            //guarda el resultado
            sumResult = sumResult.Sum(poly[i]);
        }
        //imprime el resultado de la suma
        sumResult.Print();}
        if (k == 1) {
        cout << "El producto de los polinomios es: ";
        //inicializa el objeto multResult
        Polynomial multResult = poly[0];
        for (int i = 1; i < NumPol; ++i) {
            //guarda el resultado
            multResult = multResult.Mult(poly[i]);}
        //imprime el resultado de la multiplicación
        multResult.Print();}
    //cierra el archivo
    archive.close();
    //Intenté crear un archivo pero no me printeaba, y no alcancé a solucionarlo:(
    //cout << "Archivo Polynomial.txt ha sido creado" << endl;
    return 0;
}