#include <iostream>
using namespace std;

//multiplicación escalar
class MulScalar {
    int a, b, c;
    float G;
public:
    MulScalar(int, int, int, float);
    //función void que realiza la operación
    void ms(int result[3]) { result[0] = a * G; result[1] = b * G; result[2] = c * G; }};

//suma los vectores
class VectorSum {
    int a, b, c, d, e, f;
public:
    VectorSum(int, int, int, int, int, int);
    //función void que realiza la operación
    void vs(int result[3]) { result[0] = a + d; result[1] = b + e; result[2] = c + f; }};

//producto punto
class DotProduct {
    int a, b, c, d, e, f;
public:
    DotProduct(int, int, int, int, int, int);
    //función int que realiza la operación
    int dp() { return (a * d + b * e + c * f); }};

//producto cruz
class VectorProduct {
    int a, b, c, d, e, f;
public:
    VectorProduct(int, int, int, int, int, int);
    //función int que realiza la operación
    void vp(int result[3]) { result[0] = b * f - c * e; result[1] = c * d - a * f; result[2] = a * e - b * d; }};

//aquí se declaran los constructores de las clases, para luego inicializarlos
MulScalar::MulScalar(int x, int y, int z, float g) : a(x), b(y), c(z), G(g) {}
VectorSum::VectorSum(int x, int y, int z, int d, int e, int f) : a(x), b(y), c(z), d(d), e(e), f(f) {}
DotProduct::DotProduct(int x, int y, int z, int d, int e, int f) : a(x), b(y), c(z), d(d), e(e), f(f) {}
VectorProduct::VectorProduct(int x, int y, int z, int d, int e, int f) : a(x), b(y), c(z), d(d), e(e), f(f) {}

//función principal
int main() {
    //define los valores para los vectores
    int a, b, c, d, e, f;
    //define el valor flotante
    float G;
    //pregunta por los valores en la pantalla
    cout << "Ingrese los valores del primer vector: ";
    cin >> a >> b >> c;
    cout << "Ingrese los valores del segundo vector: ";
    cin >> d >> e >> f;
    cout << "Ingrese el valor flotante: ";
    cin >> G;

    //utiliza las clases para realizar operaciones con los vectores
    MulScalar MS1(a, b, c, G);
    MulScalar MS2(d, e, f, G);
    VectorSum VS(a, b, c, d, e, f);
    DotProduct DP(a, b, c, d, e, f);
    VectorProduct VP(a, b, c, d, e, f);

    //se declararn arreglos para guardar los resultados
    float result1[3];
    int result[3];
    int scalarResult;
    int productResult[3];

    //se imprimen los resultados
    MS1.ms(result);
    cout << "El vector 1 resultante es: (" << result[0] << ", " << result[1] << ", " << result[2] << ")" << endl;
    MS2.ms(result);
    cout << "El vector 2 resultante es: (" << result[0] << ", " << result[1] << ", " << result[2] << ")" << endl;
    VS.vs(result);
    cout << "La suma de ambos vectores es: (" << result[0] << ", " << result[1] << ", " << result[2] << ")" << endl;
    scalarResult = DP.dp();
    cout << "El producto escalar es: " << scalarResult << endl;
    VP.vp(result);
    cout << "El producto vectorial es: (" << result[0] << ", " << result[1] << ", " << result[2] << ")" << endl;

    return 0;
}