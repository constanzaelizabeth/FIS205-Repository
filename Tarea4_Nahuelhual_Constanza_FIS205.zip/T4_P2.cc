#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

class RParticle {
private:
    //precisión
    double epsilon;
    //función para calcular el factor de estiramiento
    double Gamma(double beta) {return 1 / sqrt(1 - pow(beta, 2));}
    //función para calcular el factor de estiramiento
    double GammaAprox(double beta) {return 1 / sqrt(2 - beta);}

public:
    RParticle(double epsilon) : epsilon(epsilon) {}
    //método para encontrar el máximo valor de beta
    pair<double, double> MaxBetaGamma() {
        double maxBeta = 0.0; //valor máximo de beta
        double maxGamma = 0.0; //valor de gamma
        //se itera para obtener valores para beta
        for (double beta = 0.9; beta < 0.99999; beta += 0.00001) {
            //se calcula gamma
            double gamma = Gamma(beta); 
            double gammaAprox = GammaAprox(beta);
            //se calcula el error
            double fractionalError = abs(gamma - gammaAprox) / gamma;
            //actualiza el valor máximo de beta y gamma
            if (fractionalError <= epsilon) {
                maxBeta = beta;
                maxGamma = gamma;}
            else {break;} }

        return make_pair(maxBeta, maxGamma);}};

int main() {
    double epsilon = 0.001;
    RParticle particle(epsilon); // Crear un objeto de la clase RelativisticParticle
    pair<double, double> result = particle.MaxBetaGamma(); //busca máximo valor de beta y el valor de gamma
    cout << fixed << setprecision(15); //precisión de salida
    cout << "El valor máximo de beta con una precisión de una parte en mil es: " << result.first << endl;
    cout << "El correspondiente valor de gamma es: " << result.second << endl;
    return 0;
}
